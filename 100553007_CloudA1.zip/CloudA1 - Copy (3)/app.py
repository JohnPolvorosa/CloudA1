import os
import smtplib
#import cx_Oracle
import csv
#import StringIO
from flask import Flask, render_template, url_for, request, redirect, make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

#reference this
app = Flask(__name__)
#sqlite relative path
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
#initialize db
db = SQLAlchemy(app)

class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    #content is task name
    content = db.Column(db.String(200), nullable=False) #no blank task
    #completed task
    completed = db.Column(db.Integer, default=0)
    #date_goal = db.Column(db.DateTime, default= datetime.utcnow)
    date_created = db.Column(db.DateTime, default= datetime.utcnow) #mark timestamp created
    #dategoal
    #date_goal = db.Column(db.DateTime)
    def __repr__(self):
        return '<Task %r>' % self.id

@app.route('/', methods=['POST','GET']) #add POST & GET to add functionality
#define function for route
def index():
    if request.method == 'POST':
        #POST a task from input
        task_content = request.form['content']
        #todo object
        new_task = Todo(content=task_content)


        #push to db
        try:
            db.session.add(new_task)
            db.session.commit()
            return redirect('/')
        except:
            return 'Error adding a new task'

    else:
        #tasks = Todo.query.order_by(Todo.date_goal).all() #look at db contents in order they were created then grab all
        tasks = Todo.query.order_by(Todo.date_created).all() #look at db contents in order they were created then grab all
        return render_template('index.html', tasks=tasks)

#delete using id
@app.route('/delete/<int:id>')
def delete(id):
    task_to_delete = Todo.query.get_or_404(id)

    try:
        db.session.delete(task_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'Error deleting this task'

#update
@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update(id):
    task = Todo.query.get_or_404(id)

    if request.method == 'POST':
        task.content = request.form['content']

        try:
            db.session.commit()
            return redirect('/')

        except:
            return 'Error updating this task'

    else:
        return render_template('update.html', task= task)


#complete
@app.route('/complete/<int:id>')
def complete(id):
    task = Todo.query.get_or_404(id)

    #return this
    result = ''
    for c in (task.content):
        result = result + c + '\u0336'
        
    #return render_template('index.html', task=result)
    #return render_template('index.html', task = task.content)
    return result
    #return strike(task.content)
    

#strikethrough
def strike(text):
    result = ''
    for c in text:
        result = result + c + '\u0336'
    return result

@app.route("/register", methods=['POST'])
def register():
    task = request.form.get("content")
    email = request.form.get("email")
    message = request.form.get("content")
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    sender = 'uoitcloudcomputing.gmail.com'
    #server.login("uoitcloudcomputing.gmail", os.getenv("PASSWORD"))
    server.login('cloudcomputingontechu@gmail.com', 'Cloud12345')
    server.sendmail('cloudcomputingontechu@gmail.com', 'cloudcomputingontechu@gmail.com', message)
    #return render_template('index.html')
    #return('/')
    return redirect('/')
    #return render_template('index.html', task=task)

    #try:
        #smtpObj = smtplib.SMTP('localhost')
        #smtpObj.sendmail(sender, email, message)         
        #print "Successfully sent email"
        #server.login("uoitcloudcomputing.gmail", "Winner1!")
        #server.sendmail("uoitcloudcomputing.gmail", email, message)
        #return render_template('/')
   # except SMTPException:
       # return 'base.html'





#check app
if __name__ == "__main__":
    #will show errors on the webpage
    app.run(debug=True)